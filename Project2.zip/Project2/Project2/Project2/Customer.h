#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <string>
#include <iostream>
#include<stdio.h>
//using namespace std;
using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
public ref class Customer{
	
	private:
			int custId;
			String^ name;
			String^ surname;
			long idNo;
			String^ dob;
			bool atRisk;
			float creditBalance;
			
	public:

		Customer(){
		this->name = "";
		this->surname = "";
		this->idNo = 0;
		this->dob = "";
		this->creditBalance = 0.0;
		
		}
			Customer(String^ name,String^ surname,long idno,String^ dob,float credit){
				this->name = name;
				this->surname = surname;
				this->idNo = idno;
				this->dob = dob;
				this->creditBalance = credit;
				if(credit>5000.00){

				atRisk=true;
				}

			}
			int getcusId( )
			{		
				return custId;
			}
			String^ getName()
			{
				return name ;
			}
			String^ getSurname()
			{	
				return surname;
			}
			long getIdNo()
			{
				return idNo;
			}
			String^ getDob()
			{
				return dob;
			}
			bool getAtRisk()
			{
				if(creditBalance >5000){
				return true;
			}
			else{
				return false;
			}
			}
			float getCreditBalance()
			{
				return creditBalance;
			}
			  
			 
};
#endif