#pragma once
#include "Form2.h"
namespace Project2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	

	/// <summary>
	/// Summary for Form1
	/// </summary>
	
	public ref class Form1 : public System::Windows::Forms::Form
	{
		 
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::ListView^  listView1;
	protected: 
	private: System::Windows::Forms::ColumnHeader^  CustId;
	private: System::Windows::Forms::ColumnHeader^  Name;
	private: System::Windows::Forms::ColumnHeader^  Surname;
	private: System::Windows::Forms::ColumnHeader^  IDNo;
	private: System::Windows::Forms::ColumnHeader^  DOB;
	private: System::Windows::Forms::ColumnHeader^  AtRisk;

	private: System::Windows::Forms::ColumnHeader^  CreditBalance;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;

	protected: 












	private:
		/// <summary>
		/// Required designer variable.
		int arrayIndex;
		static array <Customer^>^ customerArray= gcnew array<Customer^>(9);
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->listView1 = (gcnew System::Windows::Forms::ListView());
			this->CustId = (gcnew System::Windows::Forms::ColumnHeader());
			this->Name = (gcnew System::Windows::Forms::ColumnHeader());
			this->Surname = (gcnew System::Windows::Forms::ColumnHeader());
			this->IDNo = (gcnew System::Windows::Forms::ColumnHeader());
			this->DOB = (gcnew System::Windows::Forms::ColumnHeader());
			this->AtRisk = (gcnew System::Windows::Forms::ColumnHeader());
			this->CreditBalance = (gcnew System::Windows::Forms::ColumnHeader());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// listView1
			// 
			this->listView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(7) {this->CustId, this->Name, 
				this->Surname, this->IDNo, this->DOB, this->AtRisk, this->CreditBalance});
			this->listView1->FullRowSelect = true;
			this->listView1->GridLines = true;
			this->listView1->Location = System::Drawing::Point(3, 1);
			this->listView1->Name = L"listView1";
			this->listView1->Size = System::Drawing::Size(450, 172);
			this->listView1->TabIndex = 0;
			this->listView1->UseCompatibleStateImageBehavior = false;
			this->listView1->View = System::Windows::Forms::View::Details;
			// 
			// CustId
			// 
			this->CustId->Text = L"CustId";
			// 
			// Name
			// 
			this->Name->Text = L"Name";
			// 
			// Surname
			// 
			this->Surname->Text = L"Surname";
			// 
			// IDNo
			// 
			this->IDNo->Text = L"IDNo";
			// 
			// DOB
			// 
			this->DOB->Text = L"DOB";
			// 
			// AtRisk
			// 
			this->AtRisk->Text = L"atRisk";
			// 
			// CreditBalance
			// 
			this->CreditBalance->Text = L"CreditBalance";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(3, 179);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 1;
			this->button1->Text = L"Add";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(110, 179);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 2;
			this->button2->Text = L"Edit";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(219, 179);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 3;
			this->button3->Text = L"Delete";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(342, 179);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 23);
			this->button4->TabIndex = 4;
			this->button4->Text = L"Exit";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click_1);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(458, 262);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->listView1);
//			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) 
		 
		 {
			 
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			 Form2^ frm2=gcnew Form2();	
			//calling update form
			frm2->ShowDialog(); 
			if(frm2->getCancel()!="c")
			{
				
				 
				String^ a=frm2->getName();
					String^ b=frm2->getSurname();
				if ( frm2->getcusId()!=0 && frm2->getName()!="" && frm2->getSurname()!="")
					{
						//creating customer object
						Customer^ customer =gcnew  Customer(frm2->getName(),frm2->getSurname(),frm2->getIdNo(),frm2->getDob(),frm2->getCreditBalance());
						//Checking if the array is full
						if(arrayIndex>9){
						MessageBox::Show("Memory full you can't add more data");	
						}else{
						//Assigning customer to an array
						customerArray[arrayIndex]=customer;

						ListViewItem^ lst=gcnew ListViewItem(Convert::ToString(customer->getIdNo()));
						lst->SubItems->Add(customer->getName());
						lst->SubItems->Add(Convert::ToString(customer->getSurname()));
						lst->SubItems->Add(Convert::ToString(customer->getIdNo() ));
						lst->SubItems->Add(Convert::ToString(customer->getDob()));
						lst->SubItems->Add(Convert::ToString(customer->getAtRisk()));
						lst->SubItems->Add(Convert::ToString(customer->getCreditBalance()));
						listView1->Items->Add(lst);
						MessageBox::Show("A record has been successfully added");	
						arrayIndex++ ;
						}
				}
				else
					{
						MessageBox::Show("Could not save one of the fields were empty");
					}
			}			 
			listView1->SelectedItems->Clear();

		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
 			 			Form2^ frm2=gcnew Form2();
						
			 //sending values to the update form
			 try{
				 //sets values on the update form
					frm2->setCustId(Convert::ToInt32(listView1->SelectedItems[0]->SubItems[0]->Text));
					frm2->setName(listView1->SelectedItems[0]->SubItems[1]->Text);
					frm2->setSurname(listView1->SelectedItems[0]->SubItems[2]->Text);
					frm2->setIDno(Convert::ToInt32(listView1->SelectedItems[0]->SubItems[3]->Text),"edit");
					frm2->setDob(listView1->SelectedItems[0]->SubItems[4]->Text);
					 
					frm2->setAtRisk(listView1->SelectedItems[0]->SubItems[5]->Text);
					frm2->setCreditBalance(Convert::ToDouble(listView1->SelectedItems[0]->SubItems[6]->Text));
					frm2->ShowDialog();
			 
			 
			 //getting the updated values back
			 if(frm2->getCancel()!="c")
			{
				if ( frm2->getIdNo()!=0 && frm2->getName()!="")
					{
						//declaring customer object
						Customer^ customer =gcnew  Customer(frm2->getName(),frm2->getSurname(),frm2->getIdNo(),frm2->getDob(),frm2->getCreditBalance());
						
						listView1->SelectedItems[0]->SubItems[0]->Text=Convert::ToString(customer->getIdNo());
						listView1->SelectedItems[0]->SubItems[1]->Text=customer->getName();
						listView1->SelectedItems[0]->SubItems[2]->Text=Convert::ToString(customer->getSurname());
						listView1->SelectedItems[0]->SubItems[3]->Text=Convert::ToString(customer->getIdNo());
						listView1->SelectedItems[0]->SubItems[4]->Text=Convert::ToString(customer->getDob());
						listView1->SelectedItems[0]->SubItems[5]->Text = Convert::ToString(customer->getAtRisk());
						listView1->SelectedItems[0]->SubItems[6]->Text = Convert::ToString(customer->getCreditBalance());
						MessageBox::Show("A record has been successfully edited");	
				}
				else
				{
					MessageBox::Show("Could not save one of the fields were empty");
				}
			 }
			 }
			 catch(...)
			 {
				 MessageBox::Show("You have not selected an item","No Item Selected...",MessageBoxButtons::OK,MessageBoxIcon::Warning);
			 }
			 listView1->SelectedItems->Clear();

		 }

private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) 
		 {
			  try{
					listView1->SelectedItems[0]->Text;
					Windows::Forms::DialogResult option;
					option=MessageBox::Show("You are about to delete a record\n Are you sure you want to delete?","Delete",MessageBoxButtons::YesNo,MessageBoxIcon::Exclamation);
					
					if (option==Windows::Forms::DialogResult::Yes){
						listView1->SelectedItems[0]->Remove();
					 
						option=MessageBox::Show("A record has been successfully deleted");
					}
			  }
			  catch(...)
			  {
				 MessageBox::Show("You have not selected an item","No Item Selected...",MessageBoxButtons::OK,MessageBoxIcon::Warning);
			  }
			  listView1->SelectedItems->Clear();
		 }
private: System::Void button4_Click_1(System::Object^  sender, System::EventArgs^  e) 
		 {
			 this->Close();
		 }
};

}

